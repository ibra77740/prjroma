<?php
session_start();
require "account_functions.php" ; 
if(isset($_GET['id'])){
	$newshop = new shop($_GET['id'],$_GET['nb']);
	if (isset($_SESSION['mypanel'][$_GET['id']])) {
		unset($_SESSION['mypanel'][$newshop->id]);
		$_SESSION['mypanel'][$newshop->id]=$newshop;
		$_SESSION['mypanelnb'][$newshop->id]=$_GET['nb'];
	} else {
		$_SESSION['mypanel'][$newshop->id]=$newshop;
		$_SESSION['mypanelnb'][$newshop->id]=$_GET['nb'];
	}
	$_SESSION['date']=date('d-m-y h:i:s');
	

}






?>
<!DOCTYPE HTML>

<html>
	<head>
		<title>panneau</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link rel="stylesheet" href="card.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/purecss@3.0.0/build/pure-min.css" integrity="sha384-X38yfunGUhNzHpBaEBsWLO+A0HDYOQi8ufWDkZ0k9e0eXz/tH3II7uKZ9msv++Ls" crossorigin="anonymous">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

		<style>
			#banner {
				padding: 10em 0 4.75em 0 ;
				height: 400px;
				
			}
			.pricepro{
				margin: 10px;
				font-size : 25px;
				font-weight: 900;
			}
			.footer{
				position: absolute;
				bottom: 0px;
				width: 100%;

			}
			
			</style>
	</head>
	<body class="is-preload">
		<div class="mynav ">
		<div class="rightnav ">
			<ul>
				<li id="home" class="home" >Acceul</li>
				<li id="products" >Produits</li>
				<li id="surdemande">sur demande</li>
			</ul>
		</div>
		<div class="searchcontainer ">
			<input type="text" class="searchinput" placeholder="rechercher...">
		</div>
		<div class="account pure-g">
		<?php 
				
				if(isset( $_SESSION['user'])){
					echo '<i class="fa-solid fa-bag-shopping card" id="panel"></i>';
					echo '<span class="username">';
					echo  $_SESSION['user']->nom." ". $_SESSION['user']->prenom ;
					echo '</span>';
					echo '<i class="fa-regular fa-user user"></i>';
				}else{
					echo '<button class="signupbut">sign up</button>';
					echo '<button class="signinbut">Sign in</button>';
				}



			?>
		</div>
		</div>
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
				
					

				<!-- Menu -->
					<nav id="menu">
						<div class="inner">
							<h2>Menu</h2>
							<ul class="links">
								<li><a href="index.html">Home</a></li>
								<li><a href="generic.html">Generic</a></li>
								<li><a href="elements.html">Elements</a></li>
								<li><a href="#">Log In</a></li>
								<li><a href="#">Sign Up</a></li>
							</ul>
							<a href="#" class="close">Close</a>
						</div>
					</nav>
                    <section class="paneltitles">

                    </section>
                    <section class="productspanel pure-g">
                        <div class="pure-u-1-2">
                            <?php
									$count = 0 ;
									foreach ($_SESSION['mypanel'] as $key => $val) {
										
										$article=get_article_by_id($key);
										echo '<div class="panelcard pure-g">';
										echo '<img src="'.$article['imgArt'].'" class="imgpro" alt="">';
										echo '<div class="textproduct">';
										echo '<h2>'.$article['nom'].'</h2>';
										echo '<h3 class="catlabel">'.$article['categorie'].'</h3>';
										echo '<h3 class="nb">nb : '.$_SESSION['mypanelnb'][$key].'</h3>';
										echo '</div>';
										echo '<div class="pricepro" style="color:black;" >'.$article['prix'].' DH</div>';
										echo '<div class="buttonpanel">';
										echo '<button value="'.$key.'" class="delete">delete</button>';
										echo '';
										echo '</div>';
										echo '';
										echo '';
										echo '';
										echo '</div>';
										
										$count=$count+intval($article['prix'])*intval($_SESSION['mypanelnb'][$key]);
										

									}



							?>
                           
                        </div>
                        <div class="pure-u-1-2">
						<?php

									
							echo '<div class="totalpanel">';
							echo "<h1>facture</h1>";
							echo '<h2>date:              '.$_SESSION['date'].' </h2>';
							echo '<h2>adresse:           '.$_SESSION['user']->adr.'</h2>';
							echo "<h2>total:$count DH</h2>";
							echo '<button class="buy">acheter<i class="fa-regular fa-credit-card"></i></button>';
							echo '</div>';
							?>
                        </div>


                        


                    </section>
			

					
			
					<footer>
						<div class="footer">
						<div class="row social">
						<a href="#"><i  class="fa-brands fa-facebook"></i></a>
						<a href="#"><i class="fa-brands fa-instagram"></i></a>
						<a href="#"><i class="fa-brands fa-youtube"></i></a>
						<a href="#"><i class="fa-brands fa-twitter"></i></a>
						</div>
						
						<div class="row links">
						<ul>
						<li><a href="#">Nous contacter</a></li>
						<li><a href="#">Our Services</a></li>
						<li><a href="#">Politique de confidentialité</a></li>
						<li><a href="#">termes et conditions</a></li>
						<li><a href="#">Career</a></li>
						</ul>
						</div>
						
						<div class="row">
						2023 || Designed By: master sid
						</div>
						</div>
						</footer>
					

				

							














					
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			<script>
				const rangeInput = document.querySelectorAll(".range-input input"),
				priceInput = document.querySelectorAll(".price-input input"),
				range = document.querySelector(".slider .progress");
				let priceGap = 1000;
				priceInput.forEach(input =>{
					input.addEventListener("input", e =>{
						let minPrice = parseInt(priceInput[0].value),
						maxPrice = parseInt(priceInput[1].value);
						
						if((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput[1].max){
							if(e.target.className === "input-min"){
								rangeInput[0].value = minPrice;
								range.style.left = ((minPrice / rangeInput[0].max) * 100) + "%";
							}else{
								rangeInput[1].value = maxPrice;
								range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
							}
						}
					});
				});
				rangeInput.forEach(input =>{
					input.addEventListener("input", e =>{
						let minVal = parseInt(rangeInput[0].value),
						maxVal = parseInt(rangeInput[1].value);
						if((maxVal - minVal) < priceGap){
							if(e.target.className === "range-min"){
								rangeInput[0].value = maxVal - priceGap
							}else{
								rangeInput[1].value = minVal + priceGap;
							}
						}else{
							priceInput[0].value = minVal;
							priceInput[1].value = maxVal;
							range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
							range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
						}
					});
				});


				$(".delete").click(function(){
					$id=$(".delete").val();
					$("body").fadeOut(1000, function(){
						window.location.href = "http://localhost/roma/deleteproduct.php?id="+$id;
					});
           
            

	  });
			</script>

	</body>
</html>