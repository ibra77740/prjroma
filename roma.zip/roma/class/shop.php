<?php

class shop{
    public $id;
    public $nb ;
    
    function __construct($id,$nb) {
        $this->id=$id ;
        $this->nb=$nb ;

    }
    
    function get_total(){
        return $nb ;
    }
    
}


?>